﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apophenia.Models
{
    public class Schedule
    {
        public int id;
        public DateTime Date;
        public DateTime Time;
        public string homeTeam;
        public string awayTeam;
    }
}
